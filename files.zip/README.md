# StockVault — Stock Portfolio Visualizer
### College Project | Full Stack Web Application

---

## 📌 Project Overview

StockVault is a complete **Stock Portfolio Visualizer** web application that allows users to:
- Register and log in securely
- Search and browse Indian stock market stocks
- Buy/sell stocks using a virtual balance of ₹5,00,000
- View real-time portfolio analytics with beautiful charts
- Track P&L (Profit & Loss), sector exposure, and risk metrics

---

## 🗂 Project Structure

```
stock-portfolio/
├── index.html        → Login & Signup page
├── dashboard.html    → Main portfolio dashboard
├── search.html       → Search & buy stocks
├── analytics.html    → Detailed analytics & charts
└── README.md         → This file
```

---

## 🛠 Technologies Used

| Technology | Purpose |
|---|---|
| HTML5 | Page structure |
| CSS3 | Styling, animations, responsive design |
| JavaScript (Vanilla) | Logic, state management |
| Chart.js | All charts (line, donut, bar, polar area) |
| localStorage | User data persistence (simulates a database) |
| Google Fonts | DM Serif Display, DM Sans, DM Mono |

---

## ⚙️ How It Works (Architecture)

### Frontend (3 screens)
1. **Login/Signup** (`index.html`) — Authentication UI
2. **Dashboard** (`dashboard.html`) — Overview with stats & charts
3. **Search** (`search.html`) — Browse & buy stocks
4. **Analytics** (`analytics.html`) — Advanced portfolio analytics

### Data Layer (localStorage as database)
- `sv_users` — array of all registered users
- `sv_current_user` — currently logged-in user object

Each user object stores:
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "password": "password123",
  "balance": 500000,
  "portfolio": [
    {
      "symbol": "TCS",
      "name": "Tata Consultancy Services",
      "sector": "IT",
      "qty": 5,
      "buyPrice": 3800
    }
  ]
}
```

### Stock Price Simulation
Since this is a frontend-only project (no paid API key needed), stock prices are **randomly generated** within ±8% of a realistic base price each session, simulating market fluctuations.

---

## 🚀 How to Run

1. Download the project folder
2. Open `index.html` in any modern browser (Chrome, Firefox, Edge)
3. Click **"Try Demo Account"** for instant access, OR create a new account
4. No installation, no server, no internet required (except for Google Fonts)

---

## 📊 Features

### Dashboard
- Portfolio value, total invested, P&L, available balance
- Line chart: portfolio performance over time
- Donut chart: allocation by stock
- Holdings table with real-time P&L
- Market watch panel
- Sector exposure bar chart
- Auto-refresh prices every 15 seconds

### Search Stocks
- 15 major Indian stocks (NSE)
- Search by name or symbol
- Filter by sector (IT, Finance, Energy, Auto, FMCG, Pharma)
- Sparkline mini-charts per stock
- Quick buy with quantity & price input

### Analytics
- Total return %, best/worst performer
- 12-month simulated area chart
- Pie chart allocation
- P&L bar chart (green = profit, red = loss)
- Sector polar area chart
- Performance ranking with visual bars
- Risk indicators (concentration, diversity, cash ratio)

---

## 📚 Concepts Demonstrated

- **User Authentication** — sign up, login, session management
- **CRUD Operations** — add/remove portfolio holdings
- **Data Visualization** — 6+ chart types using Chart.js
- **Responsive Design** — works on desktop, tablet, mobile
- **State Management** — persistent data across page navigation
- **Financial Calculations** — P&L, return %, portfolio weights, sector exposure

---

## 🔮 Future Enhancements (for viva)

1. **Real API Integration** — Alpha Vantage or Yahoo Finance API for live prices
2. **React Native Mobile App** — Same features on iOS/Android
3. **Node.js + Express Backend** — Real server with REST APIs
4. **MongoDB Database** — Persistent cloud storage
5. **Price Alerts** — Notify when stock hits target price
6. **Export Reports** — PDF portfolio report generation

---

## 👨‍💻 Student Information

**Project:** Stock Portfolio Visualizer  
**Course:** [Your course name]  
**Roll No:** [Your roll number]  
**College:** [Your college name]

---

*Built with ❤️ for academic purposes*
